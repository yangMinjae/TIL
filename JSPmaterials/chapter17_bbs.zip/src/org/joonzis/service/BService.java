package org.joonzis.service;

import java.util.List;

import org.joonzis.vo.BVO;

public interface BService {
	public List<BVO> getList();
}
