package org.joonzis.service;

public class CServiceImpl implements CService{

}
