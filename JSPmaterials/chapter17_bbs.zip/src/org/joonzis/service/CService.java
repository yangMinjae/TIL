package org.joonzis.service;

public interface CService {

}
