package org.joonzis.dao;

public class CDaoImpl implements CDao{

}
