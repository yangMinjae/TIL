package org.joonzis.dao;

public interface CDao {

}
