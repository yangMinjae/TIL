package org.joonzis.service;

public interface MemberService {
	public int getTupleById(String userId);
}
